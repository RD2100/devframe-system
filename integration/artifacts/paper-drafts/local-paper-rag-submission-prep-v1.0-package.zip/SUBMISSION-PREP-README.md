# Local Paper RAG Submission Prep v1.0

This package is a submission-prep supplement for the v1.0 human-review manuscript.

## Included

- local-paper-rag-clean-manuscript-v1.0.docx
- local-paper-rag-clean-manuscript-v1.0.md
- gbt7714-preflight-v1.0.md
- submission-decision-matrix-v1.0.md
- reference-format-audit-v1.0.md
- references-needs-human-check-v1.0.md
- allowed-claims-v1.0.md
- non-claim-boundary-v1.0.md

## Boundary

This is not final journal formatting, final citation acceptance, paper-quality acceptance, training-effect acceptance, production readiness, or RuntimeAuthorization.
