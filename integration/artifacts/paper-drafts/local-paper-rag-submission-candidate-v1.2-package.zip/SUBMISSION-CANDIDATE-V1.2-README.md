# Local Paper RAG Submission Candidate v1.2

This package contains a generic GB/T-style submission candidate for human
review. It is derived from the v1.1 short-paper draft.

Contents:

- `local-paper-rag-submission-candidate-v1.2.md`
- `local-paper-rag-submission-candidate-v1.2.docx`
- `local-paper-rag-reference-final-check-v1.2.md`
- `local-paper-rag-submission-format-closeout-v1.2.md`
- `local-paper-rag-submission-candidate-v1.2-manifest.json`

Boundary: this package does not grant final paper-quality acceptance,
training-effect acceptance, final governance acceptance, production readiness,
broad/general RAG readiness, whole-vault readiness, cloud/vector DB readiness,
or RuntimeAuthorization.
